import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ContentManipulator {

	public void reverseFileContent(Path inputFile, Path outFile) throws IOException {
		
		if(inputFile == null || outFile == null) {
			throw new NullPointerException("File paths can not be null");
		}
		List<String> fileContent = Files.readAllLines(inputFile, Charset.forName("ASCII"));
		Collections.reverse(fileContent);
		fileContent = fileContent.stream().map(line -> {
			StringBuilder sb = new StringBuilder(line);
			return sb.reverse().toString();
		}).collect(Collectors.toList());
		
		Files.write(outFile, fileContent, StandardOpenOption.TRUNCATE_EXISTING);
	}
}
