import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TestContentManipulator {
	
	@Test
	void testReverseContentForNullFiles() throws IOException, URISyntaxException {
		ContentManipulator cm = new ContentManipulator();
		
		Exception e = Assertions.assertThrows(NullPointerException.class, () -> cm.reverseFileContent(null, 
				null));
		Assertions.assertEquals("File paths can not be null", e.getMessage());
		
	}

	@Test
	void testReverseContent() throws IOException, URISyntaxException {
		ContentManipulator cm = new ContentManipulator();
		Path inputPath = Paths.get("src","test","resources","input.txt");
		Path outPath = Paths.get("src","test","resources","output.txt");
		cm.reverseFileContent(inputPath, 
				outPath);
	
		Assertions.assertNotNull(Files.readAllBytes(outPath));
	}
	
	
}
